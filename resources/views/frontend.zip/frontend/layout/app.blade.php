@include('frontend.layout.header')

@yield('content')

@include('frontend.layout.footer')